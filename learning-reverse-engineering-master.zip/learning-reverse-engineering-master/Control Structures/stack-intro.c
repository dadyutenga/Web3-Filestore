#include <stdio.h>

void func1(int a, int b, int c) {
	int sum = 0;
	int x = 99;

	sum = a + b + c + x;
}

int main() {
	
	func1(1,2,3);
}