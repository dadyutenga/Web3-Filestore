# OffensiveCpp
This repo contains C/C++ snippets that can be handy in specific offensive scenarios.
